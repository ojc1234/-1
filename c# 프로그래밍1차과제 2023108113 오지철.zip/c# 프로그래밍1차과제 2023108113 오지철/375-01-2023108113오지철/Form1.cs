﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _375_1_2023108113오지철
{
    /*
     * 다음 지시사항을 준숮하여 프로그램을 작성하시오
     * (1) 윈도 폼 앱 프로젝트 생성 : Test09_01
     * (2) 윈폼 앱 디자인 화면에 도구상자의 버튼 2개 배치
     * (3) 버튼 좌표값 (Location -> 첫 번째  버튼 : 35,35, 두번째 버튼 35,112
     * (4) 각 버튼의 크기 Width : 210, height : 53 (size -> 210, 53)
     * (5) 기타 사항은 실행 결과 참조
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
