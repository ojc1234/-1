﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _425_1_2023108113오지철
{
    /*
     * 다음과 같이 에러 아이콘과 함께 메시지박스가 출력되도록 소스 코드르 작성 하시오.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //메세지 박스 출력
            MessageBox.Show("약속시간이 늦었습니다", "일정",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
    }
}
