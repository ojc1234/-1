﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _425_2_2023108113오지철
{
    public partial class Form1 : Form
    {
        /*
         * 다음과 같이 느낌표 아이콘과 함께 알림이 추가된 메시지박스가 출력되도록 소스코드를 작성하시오.
         */
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //메세지 박스 출력
            MessageBox.Show("느낌표와 알림을 보여줍니다.", "안내",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        }
    }
}
