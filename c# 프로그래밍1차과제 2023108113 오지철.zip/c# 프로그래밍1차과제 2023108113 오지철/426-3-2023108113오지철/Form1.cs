﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _426_3_2023108113오지철
{
    public partial class Form1 : Form
    {
        /*
         * 다음과 같이 버튼 3개와 물음표 아이콘이 표시된 메시지박스가 출력되도록 소스코드를 작성하시오.
         */
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //메시지 박스 출력
            MessageBox.Show("3개의 버튼과 물음표 아이콘을 보여줍니다.","아이콘 표시",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
        }
    }
}
