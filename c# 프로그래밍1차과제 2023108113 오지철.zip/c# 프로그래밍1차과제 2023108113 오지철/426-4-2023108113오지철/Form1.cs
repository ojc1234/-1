﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _426_4_2023108113오지철
{
    public partial class Form1 : Form
    {
        /*
         * 다음 지시사항을 준수하여 프로그램을 작성하시오.
         * (1) 그룹박스 안에 레이블 컨트롤 도구를 배치
         * (2) 버튼에는 flag 이벤트 설정
         * (3) 버튼을 한 번 누르면 레이블에 문자열을 출력하고 또 한번 누르면 레이블의 문자열을 감춤
         * (4) 기타 사항은 실행 결과 참조
         */
        private int flag = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //버튼을 누를 때마다 플레그 값을 바꾸고
            //플레그 값을 비교하여 라벨을 보여줄지 말지 정한다.
            if (flag == 0)
            {
                flag = 1;
                label2.Visible = false;
            }
            else
            {
                flag = 0;
                label2.Visible = true;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
