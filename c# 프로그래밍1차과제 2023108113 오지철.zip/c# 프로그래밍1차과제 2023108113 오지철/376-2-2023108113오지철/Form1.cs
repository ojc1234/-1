﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _376_2_2023108113오지철
{
    /*
     * 다음 지시사항을 준수하여 프로그램을 작성하시오.
     * (1) 대상 프로젝트명 : Test09_02
     * (2) 버튼 좌표값 (Location -> 첫 번째 버튼 : 50,80. 두 번째 버튼:300,80)
     * (3) 각 버튼의 크기 Width : 200, Height : 50 (size -> 200,50)
     * (4) 각  버튼 객체의 텍스트 속성을 그림과 같이 변경
     * (5) 기타 사항은 실행 결과 참조
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
