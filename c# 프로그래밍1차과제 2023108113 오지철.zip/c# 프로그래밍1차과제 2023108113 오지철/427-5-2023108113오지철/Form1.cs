﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _427_5_2023108113오지철
{
    // 다음과 같이 주어진 실행 결과 화면을 보고 프로그램을 작성하시오.
    // (1) 오류 발생
    // (2) 정상 실행
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 변수할당 변수가 비어있다면 조건문을 사용하여 확인
            string id = this.textBox1.Text;
            string password = this.textBox2.Text;

            string moringOrAffternoon = "";
            RadioButton[] radios = new RadioButton[2] { radioButton1, radioButton2 };
            //포이치 문을 이용하여 라디오 버튼 체크를 확인하고 체크된 수업을 변수에 저장
            foreach (RadioButton rad in radios)
            {
                if (rad.Checked)
                {
                    moringOrAffternoon = rad.Text;
                }
            }
            // 학번 비밀번호 체크
            if (password == "" || id == "")
            {
                MessageBox.Show("학번 또는 비밀번호 입력 오류!", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            //라디오 버튼 체크
            else if (moringOrAffternoon =="")
            {
                MessageBox.Show("수업 버튼 체크해주세요!", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            //둘다 채워졌을 때
            else
            {
                string outputDesc = "수업을 신청한 내용입니다\n정확하게 신청했는지 확인바랍니다.\n\n"
                    + "1. 학번 :" + id + "\n"
                    + "2. 수업 :" + moringOrAffternoon;

                MessageBox.Show(outputDesc, "신청 내용");
            }
        }
    }
}
